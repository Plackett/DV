# Data Visualizer

Here is a little typescript library for generating graphs and tree diagrams.