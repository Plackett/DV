#!/bin/sh
npm i
npm test